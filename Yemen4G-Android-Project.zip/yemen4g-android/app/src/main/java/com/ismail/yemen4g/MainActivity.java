package com.ismail.yemen4g;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String SERVICE_URL = "https://svc.ptc.gov.ye/4g/";
    private final int bg = Color.rgb(7, 17, 31), panel = Color.rgb(16, 31, 51), accent = Color.rgb(34, 197, 94), text = Color.rgb(240, 246, 252), muted = Color.rgb(157, 174, 195);
    private WebView web;
    private EditText numberInput, captchaInput;
    private ImageView captchaImage;
    private TextView statusText, resultText;
    private ProgressBar progress;
    private Button queryButton, refreshButton;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean pageReady = false;
    private volatile boolean queryPending = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        buildUi(); setupWebView();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView label(String s, int size, boolean bold, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.RIGHT); t.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
    private void buildUi() {
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(bg);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(20), dp(18), dp(20), dp(22));
        scroll.addView(page); root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        TextView brand = label("إسماعيل فورجي", 26, true, text); brand.setGravity(Gravity.CENTER); page.addView(brand, lp(-1, 42));
        TextView subtitle = label("استعلام رصيد يمن فورجي 4G", 15, false, muted); subtitle.setGravity(Gravity.CENTER); page.addView(subtitle, lp(-1, 30));
        View line = new View(this); line.setBackgroundColor(Color.rgb(36, 56, 78)); LinearLayout.LayoutParams lineLp = lp(-1,1); lineLp.topMargin=dp(12); lineLp.bottomMargin=dp(18); page.addView(line,lineLp);
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(16),dp(18),dp(16),dp(18)); card.setBackground(shape(panel,18)); page.addView(card,lp(-1,-2));
        card.addView(label("رقم المودم",15,true,text),lp(-1,26));
        numberInput = new EditText(this); numberInput.setSingleLine(true); numberInput.setInputType(InputType.TYPE_CLASS_PHONE); numberInput.setHint("أدخل رقم يمن فورجي"); numberInput.setTextColor(text); numberInput.setHintTextColor(muted); numberInput.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); numberInput.setPadding(dp(12),0,dp(12),0); numberInput.setBackground(shape(Color.rgb(7,18,33),12));
        LinearLayout.LayoutParams inpLp=lp(-1,52); inpLp.topMargin=dp(8); inpLp.bottomMargin=dp(18); card.addView(numberInput,inpLp);
        card.addView(label("رمز التحقق (الكابتشا)",15,true,text),lp(-1,26));
        LinearLayout captchaRow = new LinearLayout(this); captchaRow.setOrientation(LinearLayout.HORIZONTAL); captchaRow.setGravity(Gravity.CENTER_VERTICAL); LinearLayout.LayoutParams rowLp=lp(-1,64); rowLp.topMargin=dp(8); rowLp.bottomMargin=dp(18); card.addView(captchaRow,rowLp);
        captchaImage = new ImageView(this); captchaImage.setBackground(shape(Color.WHITE,10)); captchaImage.setScaleType(ImageView.ScaleType.FIT_CENTER); LinearLayout.LayoutParams imageLp=lp(138,56); imageLp.rightMargin=dp(8); captchaRow.addView(captchaImage,imageLp);
        refreshButton = new Button(this); refreshButton.setText("تحديث"); refreshButton.setAllCaps(false); refreshButton.setTextColor(text); refreshButton.setBackground(shape(Color.rgb(42,62,85),10)); captchaRow.addView(refreshButton,lp(76,48));
        captchaInput = new EditText(this); captchaInput.setSingleLine(true); captchaInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS); captchaInput.setHint("اكتب الرمز"); captchaInput.setTextColor(text); captchaInput.setHintTextColor(muted); captchaInput.setGravity(Gravity.CENTER); captchaInput.setPadding(dp(8),0,dp(8),0); captchaInput.setBackground(shape(Color.rgb(7,18,33),10)); LinearLayout.LayoutParams capLp=new LinearLayout.LayoutParams(0,dp(48),1); capLp.leftMargin=dp(8); captchaRow.addView(captchaInput,capLp);
        queryButton = new Button(this); queryButton.setText("استعلام عن الرصيد"); queryButton.setAllCaps(false); queryButton.setTextSize(16); queryButton.setTypeface(Typeface.DEFAULT,Typeface.BOLD); queryButton.setTextColor(Color.rgb(3,25,15)); queryButton.setBackground(shape(accent,12)); card.addView(queryButton,lp(-1,54));
        LinearLayout statusCard = new LinearLayout(this); statusCard.setOrientation(LinearLayout.VERTICAL); statusCard.setPadding(dp(14),dp(12),dp(14),dp(12)); statusCard.setBackground(shape(Color.rgb(10,24,41),12)); LinearLayout.LayoutParams stLp=lp(-1,-2); stLp.topMargin=dp(14); card.addView(statusCard,stLp);
        progress = new ProgressBar(this); progress.setIndeterminate(true); progress.setVisibility(View.GONE); statusCard.addView(progress,lp(-1,24));
        statusText = label("جارٍ الاتصال بخدمة يمن فورجي…",13,false,muted); statusCard.addView(statusText,lp(-1,-2));
        LinearLayout resultCard = new LinearLayout(this); resultCard.setOrientation(LinearLayout.VERTICAL); resultCard.setPadding(dp(16),dp(14),dp(16),dp(14)); resultCard.setBackground(shape(panel,16)); LinearLayout.LayoutParams resLp=lp(-1,-2); resLp.topMargin=dp(14); page.addView(resultCard,resLp);
        resultCard.addView(label("نتيجة الاستعلام",17,true,text),lp(-1,30)); resultText = label("ستظهر بيانات الرصيد والباقة والصلاحية هنا بعد نجاح الاستعلام.",14,false,muted); resultText.setGravity(Gravity.RIGHT); resultText.setPadding(0,dp(6),0,dp(4)); resultCard.addView(resultText,lp(-1,-2));
        TextView footer=label("الاتصال مباشر بالموقع الرسمي • لا نستخدم خادمًا وسيطًا",11,false,muted); footer.setGravity(Gravity.CENTER); LinearLayout.LayoutParams fLp=lp(-1,-2); fLp.topMargin=dp(18); page.addView(footer,fLp);
        refreshButton.setOnClickListener(v -> refreshCaptcha());
        queryButton.setOnClickListener(v -> submitQuery());
        FrameLayout.LayoutParams hiddenLp = new FrameLayout.LayoutParams(dp(1),dp(1),Gravity.BOTTOM|Gravity.LEFT); hiddenLp.leftMargin=dp(1); hiddenLp.bottomMargin=dp(1);
        web = new WebView(this); web.setAlpha(0.01f); web.setBackgroundColor(bg); root.addView(web,hiddenLp);
        setContentView(root);
    }

    private void setupWebView() {
        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setLoadsImagesAutomatically(true); s.setDatabaseEnabled(true); s.setJavaScriptCanOpenWindowsAutomatically(true); s.setSupportMultipleWindows(false); s.setDefaultTextEncodingName("UTF-8");
        CookieManager cm = CookieManager.getInstance(); cm.setAcceptCookie(true); cm.setAcceptThirdPartyCookies(web,true);
        web.addJavascriptInterface(new Bridge(), "Y4GBridge"); web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view,url); pageReady = true; status("تم الاتصال بالموقع؛ جارٍ تحميل الكابتشا…", false); capturePage(0);
            }
        });
        web.loadUrl(SERVICE_URL);
    }
    private void status(String s, boolean loading) { runOnUiThread(() -> { statusText.setText(s); progress.setVisibility(loading?View.VISIBLE:View.GONE); queryButton.setEnabled(!loading); }); }
    private void refreshCaptcha() {
        captchaInput.setText(""); captchaImage.setImageDrawable(null); pageReady=false; queryPending=false; status("جارٍ تحديث الكابتشا…",true);
        web.evaluateJavascript("(function(){try{var i=document.querySelector('img[id*=captcha],img[class*=captcha],img[src*=captcha],img[src*=verification],img[src*=code]');if(i){i.click();}else{location.reload();}return 'ok';}catch(e){location.reload();return 'reload';}})()", null);
        handler.postDelayed(() -> { if (!pageReady) web.reload(); }, 1800);
    }
    private void submitQuery() {
        String number = numberInput.getText().toString().trim(); String code = captchaInput.getText().toString().trim();
        if (number.isEmpty()) { numberInput.setError("أدخل رقم المودم"); return; }
        if (code.isEmpty()) { captchaInput.setError("أدخل رمز التحقق"); return; }
        if (!pageReady) { status("الموقع لم يكتمل تحميله بعد؛ انتظر قليلًا.",false); return; }
        try { JSONObject obj = new JSONObject(); obj.put("number",number); obj.put("captcha",code); String arg = JSONObject.quote(obj.toString());
            status("جارٍ إرسال الاستعلام…",true); resultText.setText("جارٍ انتظار رد الموقع الرسمي…"); queryPending=true;
            web.evaluateJavascript("(function(payload){try{var d=JSON.parse(payload);var cap=document.querySelector('#captcha_code_q4Gbill,input[name=\\\"captcha_code_q4Gbill\\\"]');if(!cap)return 'لم أجد حقل الكابتشا';var f=cap.form;if(!f)return 'لم أجد نموذج الاستعلام';var all=Array.from(f.querySelectorAll('input')).filter(function(x){return x.type!=='hidden' && x.type!=='submit' && x.type!=='button' && x!==cap && x.name!=='captcha_code_q4Gbill';});var phone=all.find(function(x){return /phone|number|modem|bill|mobile|4g/i.test((x.name||'')+' '+(x.id||'')+' '+(x.placeholder||''));})||all[0];if(!phone)return 'لم أجد حقل رقم المودم';phone.value=d.number;phone.dispatchEvent(new Event('input',{bubbles:true}));phone.dispatchEvent(new Event('change',{bubbles:true}));cap.value=d.captcha;cap.dispatchEvent(new Event('input',{bubbles:true}));cap.dispatchEvent(new Event('change',{bubbles:true}));var btn=f.querySelector('button[type=submit],input[type=submit],#qb4g_submit,[name=qb4g_submit],[name=qsubmitnew],[name=doqbillnew],[name=querybillvaluenew]');if(btn){btn.click();}else if(f.requestSubmit){f.requestSubmit();}else{f.submit();}return 'sent';}catch(e){return 'ERROR: '+e.message;}})(" + arg + ")", value -> {
                String val = value == null ? "" : value.replaceAll("^\"|\"$", "");
                if (val.contains("ERROR") || val.contains("لم أجد")) status(val,false);
                pollPage(0);
            });
        } catch(Exception e) { status("تعذر تجهيز الاستعلام: "+e.getMessage(),false); }
    }
    private void capturePage(int count) {
        if (count > 8) return;
        captureState();
        handler.postDelayed(() -> capturePage(count+1), 1000);
    }
    private void captureState() {
        String js = "(function(){try{var im=document.querySelector('img[id*=captcha],img[class*=captcha],img[src*=captcha],img[src*=verification],img[src*=code]');var img='';if(im&&im.complete&&im.naturalWidth){try{var c=document.createElement('canvas');c.width=im.naturalWidth;c.height=im.naturalHeight;var x=c.getContext('2d');x.drawImage(im,0,0);img=c.toDataURL('image/png');}catch(e){img='';}}var body=(document.body&&document.body.innerText)||'';Y4GBridge.onState(JSON.stringify({image:img,body:body,url:location.href,hasCaptcha:!!document.querySelector('#captcha_code_q4Gbill,input[name=\\\"captcha_code_q4Gbill\\\"]')}));return 'ok';}catch(e){return 'ERR '+e.message;}})()";
        web.evaluateJavascript(js, null);
    }
    private void pollPage(int count) {
        if (!queryPending) return;
        if (count > 18) { queryPending=false; status("انتهى انتظار الرد. جرّب تحديث الكابتشا ثم أعد الاستعلام.",false); return; }
        captureState();
        handler.postDelayed(() -> pollPage(count+1), count < 4 ? 1000 : 1800);
    }
    private class Bridge {
        @JavascriptInterface public void onState(String json) {
            try {
                JSONObject o = new JSONObject(json); String image=o.optString("image",""); String body=o.optString("body",""); String url=o.optString("url","");
                runOnUiThread(() -> {
                    if (image.startsWith("data:image/")) {
                        try { String b64=image.substring(image.indexOf(',')+1); byte[] data=android.util.Base64.decode(b64,android.util.Base64.DEFAULT); Bitmap bmp=BitmapFactory.decodeByteArray(data,0,data.length); if(bmp!=null) captchaImage.setImageBitmap(bmp); } catch(Exception ignored) {}
                    }
                    if (body != null && !body.trim().isEmpty()) {
                        String normalized = body.replaceAll("[\\t ]+", " ").replaceAll("\\n{3,}","\\n").trim();
                        String lower=normalized.toLowerCase();
                        if (lower.contains("captcha") || lower.contains("رمز التحقق") || lower.contains("التحقق") || lower.contains("رقم المودم") || lower.contains("4g")) {
                            if (!lower.contains("رصيد") && !lower.contains("balance") && !lower.contains("انتهاء") && !lower.contains("الصلاحية") && !lower.contains("gb") && !lower.contains("متبقي")) {
                                if (statusText.getText().toString().contains("تم الاتصال") || statusText.getText().toString().contains("تحميل الكابتشا")) statusText.setText("الموقع جاهز. أدخل رقم المودم والكابتشا.");
                            }
                        }
                        if (queryPending && looksLikeResult(lower)) {
                            resultText.setText(extractUsefulResult(normalized)); queryPending=false; status("وصل رد من الموقع الرسمي.",false);
                        }
                    }
                });
            } catch(Exception ignored) {}
        }
    }
    private boolean looksLikeResult(String s) {
        int hits=0; String[] keys={"رصيد","balance","gb","انتهاء","الصلاحية","متبقي","الباقة","validity","expire","remaining","الحجم","جيجا"};
        for(String k:keys) if(s.contains(k)) hits++;
        return hits>=2;
    }
    private String extractUsefulResult(String s) {
        String[] lines=s.split("\\n"); StringBuilder out=new StringBuilder(); int count=0;
        for(String line:lines){ String l=line.trim(); if(l.isEmpty()) continue; String low=l.toLowerCase();
            if(low.contains("رصيد")||low.contains("balance")||low.contains("gb")||low.contains("انتهاء")||low.contains("الصلاحية")||low.contains("متبقي")||low.contains("الباقة")||low.contains("validity")||low.contains("expire")||low.contains("remaining")||low.contains("جيجا")||low.matches(".*\\d.*")) { if(out.length()>0) out.append('\n'); out.append(l); count++; if(count>=16) break; }
        }
        return out.length()>0?out.toString():s.substring(0,Math.min(1400,s.length()));
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if(web!=null){web.removeJavascriptInterface("Y4GBridge");web.destroy();} handler.removeCallbacksAndMessages(null); super.onDestroy(); }
}
