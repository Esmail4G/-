package esmail4g.net4g;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.view.animation.AlphaAnimation;
import android.view.animation.TranslateAnimation;
import android.webkit.JavascriptInterface;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.text.TextUtils;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String URL = "https://svc.ptc.gov.ye/4g/";
    private WebView web;
    private ProgressBar progress;
    private LinearLayout resultCard;
    private TextView resultText;
    private boolean resultShown = false;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int color, float radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g; }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8, 92, 115));
        getWindow().setNavigationBarColor(Color.rgb(242, 249, 252));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(242, 249, 252));

        // Branded header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(10), dp(16), dp(10));
        header.setBackground(bg(Color.rgb(8, 92, 115), 0));
        TextView logo = text("4G", 19, Color.WHITE, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(bg(Color.rgb(16, 166, 174), 14));
        header.addView(logo, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout titles = new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);
        titles.addView(text("إسماعيل فورجي", 18, Color.WHITE, true));
        TextView subtitle = text("استعلام يمن فور جي من الموقع الرسمي", 11, Color.rgb(206, 237, 242), false);
        subtitle.setPadding(0, dp(3), 0, 0); titles.addView(subtitle);
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        TextView official = text("مباشر", 11, Color.WHITE, true); official.setGravity(Gravity.CENTER);
        official.setPadding(dp(10), dp(7), dp(10), dp(7)); official.setBackground(bg(Color.rgb(12, 125, 130), 30));
        header.addView(official);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        // Developer / contact strip
        LinearLayout contact = new LinearLayout(this);
        contact.setOrientation(LinearLayout.VERTICAL);
        contact.setPadding(dp(16), dp(8), dp(16), dp(8));
        contact.setBackgroundColor(Color.WHITE);
        TextView phone = text("برمجة وتطوير: إسماعيل فورجي  •  +967 733860587", 11, Color.rgb(48, 91, 105), true);
        phone.setGravity(Gravity.CENTER); contact.addView(phone);
        root.addView(contact, new LinearLayout.LayoutParams(-1, -2));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); progress.setProgress(0); progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));

        FrameLayout content = new FrameLayout(this);
        web = new WebView(this); web.setBackgroundColor(Color.WHITE);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(false); settings.setBuiltInZoomControls(false); settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // Keep the standard WebView user agent so the official website sees a normal browser.
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.addJavascriptInterface(new ResultBridge(), "Yemen4GApp");
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                if (newProgress >= 100) progress.setVisibility(View.GONE);
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon); progress.setVisibility(View.VISIBLE); progress.setProgress(0);
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url); progress.setVisibility(View.GONE);
                // Presentation-only observer. It does not create, alter, solve or submit CAPTCHA.
                String observer = "(function(){try{if(window.__y4gObserverInstalled)return;window.__y4gObserverInstalled=true;" +
                    "var submitted=false,last='';function visible(el){return !!(el&&el.getClientRects&&el.getClientRects().length)};" +
                    "document.addEventListener('submit',function(){submitted=true;last=document.body?document.body.innerText:'';},true);" +
                    "document.addEventListener('click',function(e){var x=e.target;while(x&&x!==document){var tag=(x.tagName||'').toLowerCase();var typ=(x.getAttribute&&x.getAttribute('type')||'').toLowerCase();var tx=(x.innerText||x.value||'').trim();if(tag==='button'||tag==='input'&& (typ==='submit'||typ==='button')||/استعلام|بحث|تحقق/.test(tx)){submitted=true;last=document.body?document.body.innerText:'';break;}x=x.parentElement;}},true);" +
                    "var scan=function(){if(!submitted||!document.body)return;var body=document.body.innerText||'';if(body===last)return;" +
                    "var nodes=document.querySelectorAll('div,p,td,li,section,article,span');for(var i=nodes.length-1;i>=0;i--){var el=nodes[i];if(!visible(el))continue;var t=(el.innerText||'').trim();if(!t||t.length>260||t.length<5)continue;" +
                    "if(/الرصيد|المتبقي|المتبقية|المتبقيات|جيجابايت|صلاحية|متبقي/i.test(t)&&/[0-9٠-٩]/.test(t)&&t!==last){if(window.Yemen4GApp&&window.Yemen4GApp.onBalanceResult)window.Yemen4GApp.onBalanceResult(t);submitted=false;return;}}" +
                    "if(/خطأ|غير صحيح|تعذر|لم يتم|تحقق من الرمز|رمز التحقق/i.test(body.slice(-500))){if(window.Yemen4GApp&&window.Yemen4GApp.onQueryMessage)window.Yemen4GApp.onQueryMessage(body.slice(-240));submitted=false;}};" +
                    "new MutationObserver(scan).observe(document.documentElement,{subtree:true,childList:true,characterData:true});}catch(e){}})();";
                view.evaluateJavascript(observer, null);
            }
            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    progress.setVisibility(View.GONE);
                    new android.app.AlertDialog.Builder(MainActivity.this)
                        .setTitle("تعذر الاتصال بالموقع الرسمي")
                        .setMessage("لم يستجب الموقع أو تعذر الوصول إليه. تحقق من الإنترنت ثم اضغط إعادة المحاولة. لم يتم إنشاء نتيجة بديلة.")
                        .setPositiveButton("إعادة المحاولة", (d, w) -> web.reload())
                        .setNegativeButton("إغلاق", null).show();
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) { return false; }
        });
        content.addView(web, new FrameLayout.LayoutParams(-1, -1));

        // Animated result panel: only shown when result-like text is detected in the official page.
        resultCard = new LinearLayout(this); resultCard.setOrientation(LinearLayout.VERTICAL);
        resultCard.setPadding(dp(16), dp(12), dp(16), dp(12)); resultCard.setBackground(bg(Color.WHITE, 18));
        if (android.os.Build.VERSION.SDK_INT >= 21) resultCard.setElevation(dp(8));
        TextView resultTitle = text("نتيجة الاستعلام", 15, Color.rgb(8, 92, 115), true);
        resultCard.addView(resultTitle);
        resultText = text("", 13, Color.rgb(36, 65, 76), false); resultText.setPadding(0, dp(7), 0, 0); resultCard.addView(resultText);
        resultCard.setVisibility(View.GONE);
        FrameLayout.LayoutParams resultLp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        resultLp.setMargins(dp(12), dp(12), dp(12), 0);
        content.addView(resultCard, resultLp);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = text("© 2026 إسماعيل فورجي — جميع الحقوق محفوظة", 10, Color.rgb(88, 121, 132), false);
        footer.setGravity(Gravity.CENTER); footer.setPadding(dp(8), dp(8), dp(8), dp(8)); footer.setBackgroundColor(Color.rgb(242,249,252));
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        web.loadUrl(URL);
    }

    private void showResult(String value) {
        if (value == null) return;
        String clean = value.trim();
        if (clean.length() == 0) return;
        if (clean.length() > 240) clean = clean.substring(0, 240) + "…";
        resultText.setText(clean);
        resultCard.setVisibility(View.VISIBLE);
        resultCard.setTranslationY(-dp(24));
        resultCard.setAlpha(0f);
        resultCard.animate().translationY(0).alpha(1f).setDuration(420).start();
        resultShown = true;
    }

    private class ResultBridge {
        @JavascriptInterface public void onBalanceResult(String value) {
            runOnUiThread(() -> showResult(value));
        }
        @JavascriptInterface public void onQueryMessage(String value) {
            runOnUiThread(() -> {
                if (value != null && !value.trim().isEmpty()) showResult("رسالة من الموقع الرسمي: " + value.trim());
            });
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
