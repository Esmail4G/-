package com.ismaelfourji.yemen4g;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import android.util.Base64;

public class MainActivity extends Activity {
    WebView web;
    static final String TARGET="https://svc.ptc.gov.ye/4g/";
    static final String UA="Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36";

    @SuppressLint({"SetJavaScriptEnabled","JavascriptInterface"})
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        CookieManager.getInstance().setAcceptCookie(true);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setUserAgentString(UA);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(),"Y4G");
        web.loadUrl("file:///android_asset/index.html");
    }
    class Bridge {
        @JavascriptInterface public void init(){ new Thread(() -> { try {
            HttpURLConnection c=open(TARGET,"GET",null); int code=c.getResponseCode(); String html=read(c); storeCookies(c);
            if(code<200||code>=400) throw new IOException("HTTP "+code);
            String cap=first(html,"<img[^>]+src=[\\\"']([^\\\"']*CaptchaImage[^\\\"']*)[\\\"'][^>]*>");
            if(cap==null||cap.isEmpty()) throw new IOException("لم يتم العثور على CAPTCHA من يمن فورجي");
            String capUrl=new URL(new URL(TARGET),cap.replace("&amp;","&")).toString();
            HttpURLConnection ic=open(capUrl,"GET",null); int icode=ic.getResponseCode(); byte[] bytes=readBytes(ic); storeCookies(ic);
            if(icode<200||icode>=400) throw new IOException("تعذر تحميل CAPTCHA (HTTP "+icode+")");
            String type=ic.getContentType(); if(type==null||!type.startsWith("image/")) type="image/png";
            String data="data:"+type+";base64,"+Base64.encodeToString(bytes,Base64.NO_WRAP);
            js("window.onY4GInit("+JSONObject.quote(data)+")");
        }catch(Exception e){ js("window.onY4GError("+JSONObject.quote(e.getMessage()==null?"فشل الاتصال":e.getMessage())+")"); }}).start(); }

        @JavascriptInterface public void query(String modem,String captcha){ new Thread(() -> { try {
            HttpURLConnection g=open(TARGET,"GET",null); int gc=g.getResponseCode(); String html=read(g); storeCookies(g);
            if(gc<200||gc>=400) throw new IOException("HTTP "+gc);
            LinkedHashMap<String,String> p=hidden(html);
            p.put("ctl00$ContentPlaceHolder1$txtPhoneNumber",modem==null?"":modem);
            p.put("ctl00$ContentPlaceHolder1$txtCaptcha",captcha==null?"":captcha);
            p.put("ctl00$ContentPlaceHolder1$btnSearch","استعلام");
            byte[] body=form(p).getBytes(StandardCharsets.UTF_8);
            HttpURLConnection q=open(TARGET,"POST",body); int qc=q.getResponseCode(); String out=read(q); storeCookies(q);
            if(qc<200||qc>=400) throw new IOException("HTTP "+qc);
            JSONObject result=new JSONObject(); result.put("ok",true);
            if(Pattern.compile("رمز التحقق.{0,120}(خاطئ|غير صحيح)|(?:خاطئ|غير صحيح).{0,120}رمز التحقق",Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(out).find()){ result.put("captchaError",true); }
            else if(Pattern.compile("غير صحيح|تأكد من الرقم|غير مسجل",Pattern.CASE_INSENSITIVE).matcher(out).find()){ result.put("invalidNumber",true); }
            else result.put("data",parseResult(out));
            js("window.onY4GResult("+JSONObject.quote(result.toString())+")");
        }catch(Exception e){ js("window.onY4GError("+JSONObject.quote("تعذر الاتصال بخادم يمن فورجي: "+(e.getMessage()==null?"خطأ غير معروف":e.getMessage()))+")"); }}).start(); }

        void js(final String x){ runOnUiThread(() -> web.evaluateJavascript(x,null)); }
    }

    HttpURLConnection open(String u,String method,byte[] body)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(20000); c.setReadTimeout(25000); c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent",UA); c.setRequestProperty("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"); c.setRequestProperty("Referer",TARGET);
        String cookie=CookieManager.getInstance().getCookie(u); if(cookie!=null)c.setRequestProperty("Cookie",cookie);
        if("POST".equals(method)){ c.setDoOutput(true); c.setRequestProperty("Content-Type","application/x-www-form-urlencoded"); c.setRequestProperty("Origin","https://svc.ptc.gov.ye"); c.getOutputStream().write(body); }
        return c;
    }
    void storeCookies(HttpURLConnection c){ Map<String,List<String>> h=c.getHeaderFields(); if(h==null)return; List<String> sc=h.get("Set-Cookie"); if(sc==null)sc=h.get("set-cookie"); if(sc!=null){ CookieManager cm=CookieManager.getInstance(); for(String x:sc){ try{ String cookie=x.split(";",2)[0].trim(); if(!cookie.isEmpty()) cm.setCookie(TARGET,cookie); }catch(Exception ignored){} } cm.flush(); } }
    String read(HttpURLConnection c)throws Exception{ InputStream in; try{in=c.getInputStream();}catch(Exception e){in=c.getErrorStream();} if(in==null)return ""; return new String(readBytes(in),StandardCharsets.UTF_8); }
    byte[] readBytes(HttpURLConnection c)throws Exception{ return readBytes(c.getInputStream()); }
    byte[] readBytes(InputStream in)throws Exception{ ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] z=new byte[8192]; int n; while((n=in.read(z))!=-1)b.write(z,0,n); in.close(); return b.toByteArray(); }
    String first(String s,String re){ Matcher m=Pattern.compile(re,Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(s); return m.find()?m.group(1):""; }
    LinkedHashMap<String,String> hidden(String h){ LinkedHashMap<String,String> m=new LinkedHashMap<>(); Matcher x=Pattern.compile("<input\\b[^>]*type=[\\\"']hidden[\\\"'][^>]*>",Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(h); while(x.find()){String t=x.group();String n=attr(t,"name");if(n.isEmpty())n=attr(t,"id");if(!n.isEmpty())m.put(n,attr(t,"value"));} return m; }
    String attr(String t,String n){ Matcher m=Pattern.compile(n+"\\s*=\\s*[\\\"']([^\\\"']*)[\\\"']",Pattern.CASE_INSENSITIVE).matcher(t);return m.find()?htmlDecode(m.group(1)):""; }
    String htmlDecode(String s){ return s.replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replace("&lt;","<").replace("&gt;",">"); }
    String form(Map<String,String> p)throws Exception{ StringBuilder b=new StringBuilder(); for(Map.Entry<String,String>e:p.entrySet()){if(b.length()>0)b.append('&');b.append(URLEncoder.encode(e.getKey(),"UTF-8")).append('=').append(URLEncoder.encode(e.getValue()==null?"":e.getValue(),"UTF-8"));} return b.toString(); }
    JSONObject parseResult(String h)throws Exception{ JSONObject d=new JSONObject(); d.put("gb",extract(h,"([0-9]+(?:\\.[0-9]+)?)\\s*(?:GB|جيجا)")); d.put("money",extract(h,"([0-9]+(?:\\.[0-9]+)?)\\s*(?:ريال|YR)")); d.put("pkg",extract(h,"(4G\\s*\\d+)")); Matcher dt=Pattern.compile("\\d{2,4}[-/]\\d{1,2}[-/]\\d{2,4}").matcher(h); d.put("expiry",dt.find()?dt.group():"--/--/----"); Matcher mi=Pattern.compile("([0-9]+(?:\\.[0-9]+)?)\\s*(?:دقيقة|min)",Pattern.CASE_INSENSITIVE).matcher(h); ArrayList<String>a=new ArrayList<>();while(mi.find())a.add(mi.group(1));String on=a.size()>0?a.get(0):"--",off=a.size()>1?a.get(1):"0";d.put("onNet",on);d.put("offNet",off);try{d.put("total",on.equals("--")?"0":String.valueOf(Double.parseDouble(on)+Double.parseDouble(off)));}catch(Exception e){d.put("total","0");}return d; }
    String extract(String h,String re){Matcher m=Pattern.compile(re,Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(h);return m.find()?m.group(1):"0";}
}
